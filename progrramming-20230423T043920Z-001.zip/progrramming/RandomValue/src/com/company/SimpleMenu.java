package com.company;

public class SimpleMenu {
    // initialise instance variables
            string menuText = ""; //sets the string to null
    int optionCount = 0; //sets optionCount to 0
}
    /**
     * Method to add the options to the menu
     * @param option a String to add options to the menu
     */
    public void addOption(String option)
    {
        optionCount = optionCount + 1; //increments optionCount by 1 each time method is called
        menuText = menuText + optionCount + ") " + option + "\n"; //concatenates string menuText
    }
    /**
     * Method to display the menu
     */
    public void display()
    {
        System.out.println(menuText);// prints the concatenated string
    }
}

With a tester class like this:
        package CH3.Menu;
/**
 * Add menu options to the Simple Menu.
 * @author (Robin Witcher)
 * @version (2/7/2018)
 */
public class MenuDemo
{
    public static void main(String[] args)
    {
        SimpleMenu mainMenu = new SimpleMenu();

        mainMenu.addOption("Open new account");
        mainMenu.addOption("Log into existing account");
        mainMenu.addOption("Help");
        mainMenu.addOption("Quit");
        mainMenu.display();
    }
}
}
