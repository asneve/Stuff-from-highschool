package com.company;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        int  temp;//create a temp value for when comparing different array elements

        //User inputs the array size
        Random rand = new Random();//introduce random element into the mix


        int num[] = new int[20];//introduce the array with a limit of 2-
        System.out.println("Enter array elements:");
        for (int i = 0; i < 20; i++) {// create numbers
            num[i] = rand.nextInt(99);
        }

        for (int i = 0; i < 20; i++) {//does it for all the numbers
            for (int j = i + 1; j < 20; j++) {//looks at current location of the  array and the next to see which one is bigger
                if (num[i] > num[j]) {
                    temp = num[i];
                    num[i] = num[j];
                    num[j] = temp;
                }
            }
        }
        System.out.print("Array Elements in Ascending Order: ");
        for (int i = 0; i < 20 - 1; i++) {//prints them out
            System.out.print(num[i] + ", ");
        }
        System.out.print(num[20 - 1]);
    }
}








